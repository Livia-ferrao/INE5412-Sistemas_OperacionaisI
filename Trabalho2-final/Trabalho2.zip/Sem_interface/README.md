## COMANDOS PARA COMPILAR, EXECUTAR E TESTAR O PROGRAMA

### Para compilar, basta digitar:

```console
make all
```

### Para executar o código:

```console
make run-exemplo
```

### Para executar o código:

```console
make run-belady
```

### Para executar o código:

```console
make run-gcc
```

### Para limpar o executável:

```console
make clean
```
