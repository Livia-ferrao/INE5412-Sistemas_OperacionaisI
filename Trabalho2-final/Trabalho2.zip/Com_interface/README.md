## COMANDOS PARA COMPILAR, EXECUTAR E TESTAR O PROGRAMA

### Para compilar, basta digitar:

```console
qamke SO_project.pro
```

```console
make
```

### Para executar o código:

```console
./SO_project 4 < vsim-exemplo.txt 
```

```console
./SO_project 4 < vsim-belady.txt 
```

```console
./SO_project 4 < vsim-gcc.txt 
```
